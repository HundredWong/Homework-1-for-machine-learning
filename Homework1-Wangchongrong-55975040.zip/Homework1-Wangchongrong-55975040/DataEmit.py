# -*- coding: utf-8 -*-
"""
Created on Thu Sep 19 23:06:27 2019

@author: dell
"""

import numpy as np
import sys

v = sys.argv[1]        
m = sys.argv[2]        
n = sys.argv[3]    #Read data from the command line
    
w0 = float(v[1])
w1 = float(v[3])
w2 = float(v[5])   #Pass the parameters in vector V into w0, w1 and w2


a = int(m)
b = int(n)

while a > 0:    #Loop m positive label data
    x1 = np.random.randint(-500, 501)    
    x2 = np.random.randint(-500, 501)    
    if ((w1*x1 + w2*x2 + w0) > 0):      
        seq = [str(x1), '\t', str(x2), '\t', '+\n']
        a -= 1
        with open('train.txt','a') as f:    
            f.writelines(seq)
      
        
while b > 0:    #Loop n negative label data
    x1 = np.random.randint(-500, 501)
    x2 = np.random.randint(-500, 501)
    #if np.any((w1*x1 + w2*x2 + w0) < 0):
    if ((w1*x1 + w2*x2 + w0) < 0):  
        seq = [str(x1), '\t', str(x2), '\t', '-\n']
        b -= 1
        with open('train.txt','a') as f:
            f.writelines(seq)
            
    #txt files are automatically stored in the source file storage directory            
            
            
            