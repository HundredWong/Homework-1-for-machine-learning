# -*- coding: utf-8 -*-
"""
Created on Thu Sep 19 19:25:15 2019

@author: dell
"""


import numpy as np
import matplotlib.pyplot as plt


    #Read the data from the train.txt file
fid = open("train.txt")    #Create a handle named fid
x = []
y = []
label = []

for line in fid:    
        trainingSet = line.split('\t') 
        x.append(trainingSet[0]) 
        y.append(trainingSet[1]) 
        if trainingSet[2] == '+\n':
            label.append(1) 
        else:
            label.append(-1)
       
    #Start PLA operations
w0 = 1
w1 = 1
w2 = 1    #Initialize vetor w

while True:
    flag = True
    for i in range(0,len(label)):
        count = w0 + int(x[i])*w1 + int(y[i])*w2
        if np.sign(count) == label[i]:    
            continue
        else:
            flag = False
            w0 = w0 + label[i]
            w1 = w1 + int(x[i])*label[i]
            w2 = w2 + int(y[i])*label[i]         
    if flag:
        print(w0, '', w1, '', w2)
        break

X = np.linspace(-500, 500, 50)
Y = -w1/w2*X -w0/w2
plt.plot(X, Y)
plt.xlabel('x1')    
plt.ylabel('x2')    
plt.title('PLA Algorithm')

for i in range(0,len(x)):    
    if (label[i] == 1):
        plt.scatter(float(x[i]), float(y[i]), c='b', marker='o')
    elif (label[i] == -1):
        plt.scatter(float(x[i]), float(y[i]), c='r', marker='x')

plt.show()


























